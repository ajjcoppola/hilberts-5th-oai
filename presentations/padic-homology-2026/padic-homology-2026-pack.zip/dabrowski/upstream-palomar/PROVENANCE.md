# Provenance — Dabrowski palomar-review branch

Vendored for the Coppola archive-paper Lean extension (2026-10-17).

| Field | Value |
|-------|--------|
| Upstream | https://github.com/adbrw/HS_proof |
| Branch | `palomar-review/module-system-20261015` |
| Pin SHA | `b75523f0036bc857f31620ee18af970151036311` |
| Tip commit message | Expose relative pair implementation to compact-support proofs |
| Parent `main` (at vendor time) | see `git merge-base` / upstream `5dee340` family |
| Lean toolchain | `leanprover/lean4:v4.35.0-rc3` (from `lean-toolchain`) |
| Purpose | Compile `HSFormal`, `#print axioms`, host CoppolaHS extension modules |

## Relation to sparse audit copy

The earlier sparse vendor under `dabrowski/lean/` and `dabrowski/paper/` is pinned to
`abb0c44` (2026-10-08 audit). This directory is a **full checkout** of the later
palomar-review tip for `lake build`. Palomar commits are module-system / import
visibility changes; theorem statements claimed unchanged vs `main`.

Comparator record on upstream (axioms): at `c51a2d5` — `propext`, `Classical.choice`, `Quot.sound`.

## Honesty

Not affiliated with A. Dabrowski. Rebuild and axiom prints are recorded under
`dabrowski/lean-extension/` and the archive paper Lean appendix.
