# Presentation pack — p-adic homology manifolds (2026)

| File | Role |
|------|------|
| [`index.html`](index.html) | Reveal.js slides (~15) |
| [`checklist.pdf`](checklist.pdf) | One-page reviewer checklist |
| [`checklist.tex`](checklist.tex) | Checklist source |
| [`figures/*.mmd`](figures/) | Mermaid diagram sources |
| [`../.. /papers/padic-homology-manifolds/main.pdf`](../../papers/padic-homology-manifolds/main.pdf) | Archive paper |

Open `index.html` in a browser (needs network for Reveal/KaTeX CDN).

Sendable zip built as `padic-homology-2026-pack.zip` in this directory (when present).
